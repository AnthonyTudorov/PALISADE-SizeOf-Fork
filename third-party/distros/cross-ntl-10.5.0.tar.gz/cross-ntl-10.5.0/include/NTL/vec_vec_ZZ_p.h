
#ifndef NTL_vec_vec_ZZ_p__H
#define NTL_vec_vec_ZZ_p__H

#include <NTL/vec_ZZ_p.h>

NTL_OPEN_NNS

typedef Vec< Vec<ZZ_p> > vec_vec_ZZ_p;

NTL_CLOSE_NNS

#endif
