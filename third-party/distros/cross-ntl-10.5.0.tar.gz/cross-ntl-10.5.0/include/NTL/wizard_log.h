

/***************************
Basic Configuration Options:
NTL_THREADS
NTL_EXCEPTIONS
NTL_THREAD_BOOST
NTL_GMP_LIP

Resolution of double-word type:
__uint128_t

Performance Options:
NTL_FFT_BIGTAB
NTL_FFT_LAZYMUL
NTL_TBL_REM
NTL_CRT_ALTCODE
***************************/


