#ifndef NTL_HAVE_PCLMUL
#define NTL_HAVE_PCLMUL
#endif
